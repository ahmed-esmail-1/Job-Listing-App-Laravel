    To run it on your machine:-
1) You will need php
2) composer
3) localdb

Set up localdb, run migrations, then php artisan serve.



If you have any issues feel free to reach out.
